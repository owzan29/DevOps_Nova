<?php 

// Replace text pengaturan WP Masjid

?>

    <tr valign="top">
	    <td class="tl"><label for="sekilas"><img src="<?php echo get_template_directory_uri(); ?>/images/dev.jpg" class="dev" /></label></td>
		<td>
			<label>PRAKATA</label><br/><br/>
			Tema ini 100% FREE untuk diunduh dan dipergunakan oleh siapapun yang membutuhkan terutama bagi pengurus masjid-masjid di seluruh Indonesia.<br/><br/>
			Saya sangat berharap tema ini dapat dipergunakan dengan sebaik-baiknya dan semoga membawa banyak manfaat, terlepas dari segala kekurangan fitur yang mungkin tidak dapat dilengkapi di dalam tema ini. Dan tidak lupa saya mengucapkan banyak terima kasih atas segala dukungannya.<br/>
			Berikut ini adalah kontak personal saya
		</td>
	</tr>
	<tr valign="top">
    	<td class="tl"><label>NAMA ALIAS</label></td>
		<td>yayun</td>
	</tr>
	<tr valign="top">
    	<td class="tl"><label>EMAIL</label></td>
		<td>yayun@ciuss.com</td>
	</tr>
	<tr valign="top">
    	<td class="tl"><label>FACEBOOK</label></td>
		<td><a href="https://facebook.com/ciussgw" target="_target">facebook.com/ciussgw</a></td>
	</tr>
	<tr valign="top">
    	<td class="tl"><label>WEBSITE</label></td>
		<td><a href="https://ciuss.com" target="_target">ciuss.com</a></td>
	</tr>