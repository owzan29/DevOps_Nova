	<tr>
				<td class="tl"><label>Warna Tema</label></td>
				<td>
				    <div class="w20">
    					<div class="pw donker">
			        	<div class="wpinn clear">
						    <div>
						        <div class="inblock">
							    	<input type="radio" name="weecolor" value="default" class="chng widefat" <?php echo (get_option('weecolor') == 'default') ? 'checked="checked"' : ''; ?>/>
									<span class="bold"><?php _e('Donker', 'mading'); ?></span>
						        </div>
						        <div class="fourinn" style="background: #003366;">
								</div>
								<div class="fourinn" style="background: #eeeeee;">
								</div>
								<div class="fourinn" style="background: #ffcc00;">
								</div>
								<div class="fourinn" style="background: #003366;">
								</div>
							</div>
						</div>
						</div>
					</div>
					<div class="w20">
    					<div class="pw tosca">
			        	<div class="wpinn clear">
						    <div>
						        <div class="inblock">
							    	<input type="radio" name="weecolor" value="tosca" class="chng" <?php echo (get_option('weecolor') == 'tosca') ? 'checked="checked"' : ''; ?>/>
									<span class="bold"><?php _e('Black Tosca', 'mading'); ?></span>
						        </div>
								<div class="fourinn" style="background: #2bc784;">
								</div>
								<div class="fourinn" style="background: #25313e;">
								</div>
								<div class="fourinn" style="background: #dddddd;">
								</div>
								<div class="fourinn" style="background: #0e975c;">
								</div>
							</div>
						</div>
						</div>
					</div>
					
					<div class="w20">
    					<div class="pw purple">
			        	<div class="wpinn clear">
						    <div>
						        <div class="inblock">
							    	<input type="radio" name="weecolor" value="purple" class="chng" <?php echo (get_option('weecolor') == 'purple') ? 'checked="checked"' : ''; ?>/>
									<span class="bold"><?php _e('Purple', 'mading'); ?></span>
						        </div>
								<div class="fourinn" style="background: #b42c7b;">
								</div>
								<div class="fourinn" style="background: #fdfdfd;">
								</div>
								<div class="fourinn" style="background: #510474;">
								</div>
								<div class="fourinn" style="background: #b8b2fb;">
								</div>
							</div>
						</div>
						</div>
					</div>
					
					<div class="w20">
    					<div class="pw orange">
			        	<div class="wpinn clear">
						    <div>
						        <div class="inblock">
							    	<input type="radio" name="weecolor" value="orange" class="chng" <?php echo (get_option('weecolor') == 'orange') ? 'checked="checked"' : ''; ?>/>
									<span class="bold"><?php _e('Orange', 'mading'); ?></span>
						        </div>
								<div class="fourinn" style="background: #ff9900;">
								</div>
								<div class="fourinn" style="background: #444444;">
								</div>
								<div class="fourinn" style="background: #ef761b;">
								</div>
								<div class="fourinn" style="background: #fba82a;">
								</div>
							</div>
						</div>
						</div>
					</div>
					
					<div class="w20">
    					<div class="pw red">
			        	<div class="wpinn clear">
						    <div>
						        <div class="inblock">
							    	<input type="radio" name="weecolor" value="red" class="chng" <?php echo (get_option('weecolor') == 'red') ? 'checked="checked"' : ''; ?>/>
									<span class="bold"><?php _e('Dark Red', 'mading'); ?></span>
						        </div>
								<div class="fourinn" style="background: #dd3333;">
								</div>
								<div class="fourinn" style="background: #be1e1e;">
								</div>
								<div class="fourinn" style="background: #dddddd;">
								</div>
								<div class="fourinn" style="background: #333333;">
								</div>
							</div>
						</div>
						</div>
					</div>
					
					<div class="w20">
    					<div class="pw green">
			        	<div class="wpinn clear">
						    <div>
						        <div class="inblock">
							    	<input type="radio" name="weecolor" value="green" class="chng" <?php echo (get_option('weecolor') == 'green') ? 'checked="checked"' : ''; ?>/>
									<span class="bold"><?php _e('Green', 'mading'); ?></span>
						        </div>
								<div class="fourinn" style="background: #59c54d;">
								</div>
								<div class="fourinn" style="background: #222222;">
								</div>
								<div class="fourinn" style="background: #8ed386;">
								</div>
								<div class="fourinn" style="background: #0fa10f;">
								</div>
							</div>
						</div>
						</div>
					</div>
					
					<div class="w20">
    					<div class="pw blue">
			        	<div class="wpinn clear">
						    <div>
						        <div class="inblock">
							    	<input type="radio" name="weecolor" value="blue" class="chng" <?php echo (get_option('weecolor') == 'blue') ? 'checked="checked"' : ''; ?>/>
									<span class="bold"><?php _e('Blue', 'mading'); ?></span>
						        </div>
								<div class="fourinn" style="background: #1777ce;">
								</div>
								<div class="fourinn" style="background: #003366;">
								</div>
								<div class="fourinn" style="background: #68b3f6;">
								</div>
								<div class="fourinn" style="background: #222222;">
								</div>
							</div>
						</div>
						</div>
					</div>
					
					<div class="w20">
    					<div class="pw resetcol">
			        	<div class="wpinn clear">
						    <div>
						        <div class="inblock">
							    	<input type="radio" name="weecolor" value="resetcol" class="chng" <?php echo (get_option('weecolor') == 'resetcol') ? 'checked="checked"' : ''; ?>/><span class="bold"><?php _e('RESET COLOR', 'mading'); ?></span>
						        </div>
							</div>
						</div>
						</div>
					</div>
					<div class="clear">
					</div>
		    	</td>
    </tr>
			
			
	<tr valign="top">
        <td class="tl">
		    <label><?php _e('CUSTOM COLOR', 'mading'); ?></label>
		</td>
	    <td>
		    <div class="ready">
				<div class="clear">
					Anda dapat melakukan pengaturan pewarnaan sendiri di bagian Custom Color dibawah ini, pewarnaan default mengikuti Color Style yang dipilih di bagian atas.
		    	</div>
			</div>
		</td>
	</tr>


	<tr valign="top">
        <td class="tl">
		    <label><?php _e('Global Setting', 'weesata'); ?></label>
		</td>
	    <td>
		    <div class="ready">
			    <div class="closed <?php echo (get_option('custom')) ? get_option('custom') : 'nocustom' ?>">
			    </div>				
				<div class="clear">
				    <div class="quarter">
				        <label><?php _e('Text Color', 'weesata'); ?></label> 
					</div>
					<div class="quarter">
				        <input type="text" name="globaltc" id="globaltc" class="coloring" value="<?php echo get_option('globaltc'); ?>"/> 
					</div>
				</div>
				<div class="clear">
				    <div class="quarter">
				        <label><?php _e('Link Color', 'weesata'); ?></label> 
					</div>
					<div class="quarter">
				        <input type="text" name="globallc" id="globallc" class="coloring" value="<?php echo get_option('globallc'); ?>"/> 
					</div>
				</div>
			</div>
		</td>
	</tr>