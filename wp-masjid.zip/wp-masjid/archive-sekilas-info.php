<?php get_header(); ?>

    	<div class="container">
            <div class="notfound">
		        	<h1>
			        	Konten Tidak Ditampilkan
		        	</h1>
			    	Data sekilas info tidak ditampilkan dihalaman ini, sekilas info ditampilkan dalam text berjalan (bagian atas).
				</div>
    	</div>

<?php get_footer(); ?>
