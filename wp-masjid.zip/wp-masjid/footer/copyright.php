		<div class="footer clear">
	    	<div class="mas-nav clear">
				<div class="copyright">
					Copyright &copy; <a href="<?php echo home_url(); ?>"><?php bloginfo('name'); ?></a>.
					<span><?php _e('Didukung oleh', 'wpmasjid'); ?> <a href="https://wordpress.org">WordPress</a>. <?php _e('Tema WP Masjid oleh', 'wpmasjid'); ?> <a href="https://ciuss.com">Ciuss Creative</a></span>
				</div>
			</div>
		</div>