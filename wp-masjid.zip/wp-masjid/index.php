<?php get_header(); ?>

    	<section class="weefirst">
     	    <div class="container clear">
     	     	<div class="pack-one clear">
		            	<?php get_template_part('loop/loop'); ?>
		        	</div>
		        	<div class="inipage clear">
		            	<?php get_template_part('pagination'); ?>
		        	</div>
		     	</div>
	    	</div>
        </section>
	
<?php get_footer(); ?>
